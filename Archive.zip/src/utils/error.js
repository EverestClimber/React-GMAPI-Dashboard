export const errorMessage = str => str.replace(/^\[.*\]/, '')
