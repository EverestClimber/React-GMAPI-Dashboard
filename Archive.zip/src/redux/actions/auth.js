import Types from './types'

export const loginSucceeded = () =>
  ({ type: Types.LOGIN_SUCCEEDED })