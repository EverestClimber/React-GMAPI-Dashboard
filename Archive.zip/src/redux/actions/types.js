import { createTypes } from 'reduxsauce'

export default createTypes(`
  LOGIN_SUCCEEDED
`)
