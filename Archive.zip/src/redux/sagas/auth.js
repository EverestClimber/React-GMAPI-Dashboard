import { put, call, take, takeLatest } from 'redux-saga/effects'
import Types from '../actions/types'

import * as Actions from '../actions/auth'

import { NotificationManager } from 'react-notifications'

import { push } from 'react-router-redux'

// Saga: will be fired on LOGIN_REQUESTED actions
function* loginSucceeded(action) {
   try {
    //  NotificationManager.success(`Welcome ${ action.userName }`, 'Welcome')
   } catch (e) {
   }
}

/*
  Does not allow concurrent fetches.
*/
export function* authSaga() {
  yield takeLatest(Types.LOGIN_SUCCEEDED, loginSucceeded)
}
