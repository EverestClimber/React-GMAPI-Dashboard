import { authSaga } from './auth'

export default [
  authSaga
]
