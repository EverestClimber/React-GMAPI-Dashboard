import { createReducer } from 'reduxsauce'
// Import Actions
import Types from '../actions/types'

// Initial State
const initialState = {
  state: 'NOT_LOGGED'
}

/* Handlers */

export const loginSucceeded = (state = initialState) => {
  return { state: 'LOGGED' }
}

// map action types to reducer functions
export const handlers = {
  [Types.LOGIN_SUCCEEDED]: loginSucceeded,
}

/* Selectors */


// Export Reducer
export default createReducer(initialState, handlers)
