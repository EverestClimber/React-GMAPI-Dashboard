import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'

// Import styles
import './styles/styles.css'

// Import components
import classNames from 'classnames';
import { withStyles } from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import List from '@material-ui/core/List';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';
import IconButton from '@material-ui/core/IconButton';
import Badge from '@material-ui/core/Badge';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import NotificationsIcon from '@material-ui/icons/Notifications';

import HeaderBar from './components/HeaderBar'
import SideBar from './components/SideBar'
// Import routes
import routes from './routes'

// Import Actions


const drawerWidth = 240;

class App extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      open: true,
    }
  }

  componentDidMount() {
    
  }

  handleSideBarClose = () => {
    this.setState({ open: false });
  }

  handleSideBarOpen = () => {
    this.setState({ open: true });
  } 

  render() {
    const { classes } = this.props;

    return (
      <React.Fragment>
        <CssBaseline />
        <div className={classes.root}>
          <HeaderBar isOpened={this.state.open} handleSideBarOpen={this.handleSideBarOpen}/>
          <SideBar isOpened={this.state.open} handleSideBarClose={this.handleSideBarClose}/>
          <main className={classes.content}>
            <div className={classes.appBarSpacer} />
            AAAAAA
            { routes }
          </main>
        </div>
      </React.Fragment>
    )
  }
}

const styles = theme => ({
  root: {
    display: 'flex',
  },
  appBarSpacer: theme.mixins.toolbar,
  content: {
    flexGrow: 1,
    padding: theme.spacing.unit * 3,
    height: '100vh',
    overflow: 'auto',
  },
});

App.propTypes = {
  classes: PropTypes.object.isRequired,
};

// Retrieve data from store as props
function mapStateToProps(state) {
  return {

  }
}

export default connect(mapStateToProps)(withStyles(styles)(App))
