import React from 'react'
import { Switch, Route, Redirect } from 'react-router-dom'

// Import Components
import asyncComponent from '../../components/AsyncComponent'

import Authentication from '../Authentication'

const AsyncMain = asyncComponent(() => import('../Main'))

const routes = (
  <Switch path='/'>
    <Route path='/main' component={ AsyncMain } />
    <Route path='/auth' component={ Authentication } />

    <Redirect exact path='/' to='/main' />
    <Redirect path='*' to='/' />
  </Switch>
)

export default routes
